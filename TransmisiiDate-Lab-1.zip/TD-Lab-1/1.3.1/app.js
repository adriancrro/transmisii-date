console.log("Welcome to data transmission ");

document.getElementById("message").innerHTML = "Message from JavaScript";